<?php

namespace App\Interfaces\Repositories;


interface BannerRepositoryInterface
{
    public function getModel(): mixed;

}
